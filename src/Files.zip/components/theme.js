const theme = {
    display: 'flex',
    height: '200px',
    width: '220px',
    alignSelf: 'center'
}

export const theme2 = {
    display: 'flex',
    textAlign: 'center',
    flexDirection: 'column'
}

export default theme;